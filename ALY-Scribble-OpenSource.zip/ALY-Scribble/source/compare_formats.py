"""Check that ALY TTF, CFF OTF and WOFF2 expose equivalent glyphs/shaping.

Usage: python compare_formats.py output_directory
WOFF2 is decompressed using fontTools before shaping; a browser preview must
separately verify the browser's WOFF2 loading and rasterizer.
"""
from __future__ import annotations
import io
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "vendor"))

from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen
import uharfbuzz as hb

SAMPLES = [
    ("علي", "rtl", "arab", "ar"),
    ("عــــلــــي", "rtl", "arab", "ar"),
    ("عَلِيٌّ شَدَّة قَهْوَةٌ بِّ بَّ بُّ", "rtl", "arab", "ar"),
    ("لا لأ لإ لآ بلا بلأ بلإ بلآ", "rtl", "arab", "ar"),
    ("لَا لِإ لُأ لّآ لَّأ بلَا بَلَّإ لَّا لٌّا", "rtl", "arab", "ar"),
    ("بَ" + "ـ"*64 + "بِّ", "rtl", "arab", "ar"),
    ("بّّ بََ بًّ بٌّ بٍّ", "rtl", "arab", "ar"),
    ("عربي فارسی اردو", "rtl", "arab", "ar"),
    ("لا لأ لإ لآ بلا بلأ بلإ بلآ", "rtl", "arab", "fa"),
    ("لا لأ لإ لآ بلا بلأ بلإ بلآ", "rtl", "arab", "ur"),
    ("٠١٢٣٤٥٦٧٨٩ ۰۱۲۳۴۵۶۷۸۹ 0123456789", "ltr", "arab", "ar"),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz", "ltr", "latn", "en"),
    ("ALY ali Aly | Photography, Gaming & Coffee", "ltr", "latn", "en"),
    ("AV AW AY VA WA YA To Ta Te Yo Vo LT fa", "ltr", "latn", "en"),
    ("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", "ltr", "latn", "en"),
]


def shape(font, text, direction, script, language):
    buf = hb.Buffer()
    buf.add_codepoints([ord(c) for c in text])
    buf.direction, buf.script, buf.language = direction, script, language
    hb.shape(font, buf)
    return [[a.codepoint, a.cluster, p.x_advance, p.y_advance, p.x_offset, p.y_offset]
            for a, p in zip(buf.glyph_infos, buf.glyph_positions)]


def snapshot(path):
    font = TTFont(path, lazy=False)
    font.flavor = None
    saved = io.BytesIO()
    font.save(saved)
    hbfont = hb.Font(hb.Face(saved.getvalue()))
    hb.ot_font_set_funcs(hbfont)
    upem = font["head"].unitsPerEm
    hbfont.scale = (upem, upem)
    order = font.getGlyphOrder()
    glyphs = font.getGlyphSet()
    bounds = {}
    for name in order:
        pen = BoundsPen(glyphs)
        glyphs[name].draw(pen)
        bounds[name] = pen.bounds
    return {"path": str(path), "file_bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "cmap": font.getBestCmap(), "glyph_order": order,
            "hmtx": font["hmtx"].metrics, "bounds": bounds,
            "gsub": font["GSUB"].compile(font), "gpos": font["GPOS"].compile(font),
            "gdef": font["GDEF"].compile(font),
            "shaping": [shape(hbfont, *sample) for sample in SAMPLES]}


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python compare_formats.py output_directory")
    directory = Path(sys.argv[1]).resolve()
    checks = []
    formats = []
    for style in ("Regular", "Bold"):
        baseline = snapshot(directory / f"ALYScribble-{style}.ttf")
        formats.append({"style": style, "format": "ttf", "path": baseline["path"],
                        "bytes": baseline["file_bytes"], "sha256": baseline["sha256"]})
        for extension in ("otf", "woff2"):
            compared = snapshot(directory / f"ALYScribble-{style}.{extension}")
            formats.append({"style": style, "format": extension, "path": compared["path"],
                            "bytes": compared["file_bytes"], "sha256": compared["sha256"]})
            for field in ("cmap", "glyph_order", "hmtx", "bounds", "gsub", "gpos", "gdef"):
                checks.append({"style": style, "format": extension,
                               "check": field + "_matches_ttf", "pass": compared[field] == baseline[field]})
            for index, sample in enumerate(SAMPLES):
                checks.append({"style": style, "format": extension, "check": "shaping_matches_ttf",
                               "text": sample[0], "language": sample[3],
                               "pass": compared["shaping"][index] == baseline["shaping"][index]})
                checks.append({"style": style, "format": extension, "check": "shaped_text_no_notdef",
                               "text": sample[0], "language": sample[3],
                               "pass": not any(row[0] == 0 for row in compared["shaping"][index])})
    errors = [check for check in checks if not check["pass"]]
    report = {"status": "fail" if errors else "pass", "checks": checks, "errors": errors,
              "formats": formats, "samples_per_format": len(SAMPLES),
              "limits": ["WOFF2 is decoded by fontTools before HarfBuzz shaping. Browser WOFF2 loading requires separate visual QA.",
                         "This comparison covers the listed structural data, glyph bounds and sample shaping, not physical device installation."]}
    target = directory / "qa-format-equivalence.json"
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass
    print(json.dumps({"status": report["status"], "checks": len(checks), "errors": errors, "report": str(target)}, ensure_ascii=False))
    raise SystemExit(1 if errors else 0)


if __name__ == "__main__":
    main()
