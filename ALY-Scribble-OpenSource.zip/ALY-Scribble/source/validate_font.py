"""Independent structural and shaping QA for the ALY Arabic/Latin font.

Usage: python validate_font.py font.ttf [report.json]
Exit 0 means these checks passed; it is not a guarantee about every app/device.
The test deliberately checks behavior, not just the presence of GSUB/GPOS tags.
"""
from __future__ import annotations

import io
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import traceback

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "vendor"))

from fontTools.ttLib import TTFont
from fontTools.pens.recordingPen import RecordingPen
from fontTools.pens.basePen import BasePen
from shapely.geometry import Polygon, box
from shapely.affinity import translate
from shapely.ops import unary_union
from shapely.validation import explain_validity
import uharfbuzz as hb


CORE_ARABIC = list(range(0x0621, 0x063B)) + list(range(0x0641, 0x064B))
ARABIC_MARKS = list(range(0x064B, 0x0656)) + [0x0670]
RIGHT_JOINING = {0x0622, 0x0623, 0x0624, 0x0625, 0x0627, 0x0629,
                 0x062F, 0x0630, 0x0631, 0x0632, 0x0648}
NON_JOINING = {0x0621}
DUAL_JOINING = set(CORE_ARABIC) - RIGHT_JOINING - NON_JOINING
REQUIRED = {
    "ASCII_printable": list(range(0x20, 0x7F)),
    "Arabic_core_letters": CORE_ARABIC,
    "Arabic_vowel_marks": ARABIC_MARKS,
    "Arabic_Indic_digits": list(range(0x0660, 0x066A)),
    "Extended_Arabic_Indic_digits": list(range(0x06F0, 0x06FA)),
    "Arabic_punctuation_and_tatweel": [0x060C, 0x061B, 0x061F, 0x0640, 0x066A, 0x066B, 0x066C],
}


def cp_label(cp):
    return f"U+{cp:04X} {chr(cp)}"


class FlattenPen(BasePen):
    """Flatten glyph contours independently of the designer's geometry source."""
    def __init__(self, glyphset):
        super().__init__(glyphset)
        self.contours = []
        self.points = []

    def _moveTo(self, p):
        self.points = [p]

    def _lineTo(self, p):
        self.points.append(p)

    def _curveToOne(self, p1, p2, p3):
        p0 = self._getCurrentPoint()
        for step in range(1, 25):
            t, s = step/24, 1-step/24
            self.points.append((s**3*p0[0] + 3*s*s*t*p1[0] + 3*s*t*t*p2[0] + t**3*p3[0],
                                s**3*p0[1] + 3*s*s*t*p1[1] + 3*s*t*t*p2[1] + t**3*p3[1]))

    def _qCurveToOne(self, p1, p2):
        p0 = self._getCurrentPoint()
        for step in range(1, 21):
            t, s = step/20, 1-step/20
            self.points.append((s*s*p0[0] + 2*s*t*p1[0] + t*t*p2[0],
                                s*s*p0[1] + 2*s*t*p1[1] + t*t*p2[1]))

    def _closePath(self):
        if len(self.points) >= 3:
            self.contours.append(self.points)
        self.points = []

    def _endPath(self):
        self._closePath()


class FontQA:
    def __init__(self, path):
        self.path = Path(path).resolve()
        self.raw = self.path.read_bytes()
        self.font = TTFont(io.BytesIO(self.raw), lazy=False)
        self.order = self.font.getGlyphOrder()
        self.cmap = self.font.getBestCmap() or {}
        self.glyphset = self.font.getGlyphSet()
        self.bounds = {}
        self.geometry_cache = {}
        self.face = hb.Face(self.raw)
        self.hbfont = hb.Font(self.face)
        hb.ot_font_set_funcs(self.hbfont)
        self.upem = self.font["head"].unitsPerEm
        self.hbfont.scale = (self.upem, self.upem)
        self.errors = []
        self.warnings = []
        self.checks = []
        self.shaping = []
        self.stats = {}

    def check(self, name, passed, details=None, warning=False):
        item = {"check": name, "status": "pass" if passed else ("warning" if warning else "fail")}
        if details is not None:
            item["details"] = details
        self.checks.append(item)
        if not passed:
            (self.warnings if warning else self.errors).append(item)
        return bool(passed)

    def shape(self, text, direction="rtl", script="arab", features=None):
        buf = hb.Buffer()
        # Explicit codepoint clusters avoid utf8 byte-offset ambiguity.
        buf.add_codepoints([ord(c) for c in text])
        buf.direction = direction
        buf.script = script
        buf.language = "ar" if script == "arab" else "en"
        hb.shape(self.hbfont, buf, features or {})
        shaped = []
        for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
            shaped.append({
                "glyph": self.order[info.codepoint], "gid": info.codepoint,
                "cluster": info.cluster, "x_advance": pos.x_advance,
                "y_advance": pos.y_advance, "x_offset": pos.x_offset,
                "y_offset": pos.y_offset,
            })
        return shaped

    def base_at_cluster(self, shaped, cluster):
        marks = {self.cmap.get(cp) for cp in ARABIC_MARKS}
        return next((g["glyph"] for g in shaped
                     if g["cluster"] == cluster and g["glyph"] not in marks
                     and g["x_advance"] != 0), None)

    def glyph_form(self, cp, suffix):
        base = self.cmap.get(cp)
        if base is None:
            return None
        if suffix == "isol":
            return base + ".isol" if base + ".isol" in self.order else base
        candidate = base + "." + suffix
        return candidate if candidate in self.order else None

    def geometry(self, name):
        if name not in self.geometry_cache:
            pen = FlattenPen(self.glyphset)
            self.glyphset[name].draw(pen)
            rings = [Polygon(c).buffer(0) for c in pen.contours if len(c) >= 3]
            result = Polygon()
            # Fontbuilder emits disjoint outer contours with interior counters.
            # Even-odd reconstruction preserves counters regardless of winding.
            for ring in rings:
                result = result.symmetric_difference(ring)
            self.geometry_cache[name] = result
        return self.geometry_cache[name]

    def structure(self):
        required = ["head", "hhea", "maxp", "OS/2", "hmtx", "cmap", "name", "post"]
        self.check("required_tables", all(t in self.font for t in required),
                   {"missing": [t for t in required if t not in self.font]})
        self.check("TrueType_outline_tables", "glyf" in self.font and "loca" in self.font)
        self.check("units_per_em_valid", 16 <= self.upem <= 16384, self.upem)
        self.check("glyph_zero_is_notdef", self.order[0] == ".notdef", self.order[0])
        self.check("glyph_count_consistent", self.font["maxp"].numGlyphs == len(self.order), len(self.order))
        self.check("unique_glyph_names", len(self.order) == len(set(self.order)))
        fs_type = self.font["OS/2"].fsType
        self.check("unrestricted_font_embedding", fs_type == 0, {"OS2_fsType": fs_type})
        bad_mapped = [{"codepoint": cp_label(cp), "glyph": gn} for cp, gn in self.cmap.items()
                      if gn not in self.order or gn == ".notdef"]
        self.check("cmap_references_valid_glyphs", not bad_mapped, bad_mapped)
        for group, cps in REQUIRED.items():
            missing = [cp_label(cp) for cp in cps if cp not in self.cmap]
            self.check("cmap_" + group, not missing, {"missing": missing, "expected_count": len(cps)})
        # These are useful additional Arabic/Persian characters, not a claim of full Unicode coverage.
        optional = [0x00A0, 0x0610, 0x0611, 0x0612, 0x0613, 0x0614, 0x0615, 0x0616,
                    0x0617, 0x0618, 0x0619, 0x061A, 0x0671, 0x067E, 0x0686, 0x0698, 0x06A9, 0x06AF, 0x06CC]
        absent = [cp_label(cp) for cp in optional if cp not in self.cmap]
        self.check("additional_language_coverage", not absent, {"not_covered": absent}, warning=True)
        names = {}
        for record in self.font["name"].names:
            if record.nameID in (0, 1, 2, 3, 4, 5, 6, 8, 9, 13, 14, 16, 17):
                try:
                    value = record.toUnicode()
                    names.setdefault(str(record.nameID), []).append(value)
                except Exception as exc:
                    self.check("name_record_decodes", False, str(exc))
        names = {k: sorted(set(v)) for k, v in names.items()}
        self.stats["names"] = names
        family = " ".join(names.get("1", []) + names.get("16", []))
        self.check("ALY_family_name", "ALY" in family.upper() or "علي" in family, family)
        self.check("license_metadata_present", bool(names.get("13")) and bool(names.get("14")),
                   {"license_text": names.get("13"), "license_url": names.get("14")}, warning=True)
        self.check("postscript_name_safe", all(all(33 <= ord(c) <= 126 and c not in "[](){}<>/%" for c in n)
                                                 for n in names.get("6", [])) and bool(names.get("6")), names.get("6"))
        subfamily = " ".join(names.get("2", []) + names.get("17", [])).lower()
        is_bold = "bold" in subfamily
        is_regular = "regular" in subfamily
        os2 = self.font["OS/2"]
        mac_bold = bool(self.font["head"].macStyle & 1)
        os2_bold = bool(os2.fsSelection & (1 << 5))
        os2_regular = bool(os2.fsSelection & (1 << 6))
        self.check("style_flags_match_subfamily", (is_bold and mac_bold and os2_bold and not os2_regular)
                   or (is_regular and not mac_bold and not os2_bold and os2_regular),
                   {"subfamily": subfamily, "head_macStyle": self.font["head"].macStyle,
                    "OS2_fsSelection": os2.fsSelection, "OS2_weight_class": os2.usWeightClass})
        self.check("weight_class_matches_style", (is_bold and os2.usWeightClass == 700)
                   or (is_regular and os2.usWeightClass == 400), os2.usWeightClass)
        self.check("Arabic_unicode_range_metadata", bool(os2.ulUnicodeRange1 & (1 << 13)),
                   {"OS2_ulUnicodeRange1": os2.ulUnicodeRange1}, warning=True)
        directory = []
        table_count = struct.unpack_from(">H", self.raw, 4)[0]
        for i in range(table_count):
            tag, expected, offset, length = struct.unpack_from(">4sIII", self.raw, 12 + 16*i)
            data = self.raw[offset:offset+length]
            valid_range = offset + length <= len(self.raw) and offset % 4 == 0
            if tag == b"head":
                data = data[:8] + b"\0\0\0\0" + data[12:]
            padded = data + b"\0" * ((-len(data)) % 4)
            actual = sum(struct.unpack(">" + "I"*(len(padded)//4), padded)) & 0xFFFFFFFF
            if not valid_range or actual != expected:
                directory.append({"table": tag.decode("ascii", errors="replace"),
                                  "valid_range": valid_range, "stored": expected, "computed": actual})
        self.check("sfnt_table_checksums_and_ranges", not directory, directory)
        padded_font = self.raw + b"\0" * ((-len(self.raw)) % 4)
        total = sum(struct.unpack(">" + "I"*(len(padded_font)//4), padded_font)) & 0xFFFFFFFF
        self.check("whole_font_checksum", total == 0xB1B0AFBA, f"0x{total:08X}")
        try:
            stream = io.BytesIO()
            self.font.save(stream)
            roundtrip = TTFont(io.BytesIO(stream.getvalue()), lazy=False)
            self.check("fonttools_save_reload", roundtrip.getBestCmap() == self.cmap
                       and roundtrip.getGlyphOrder() == self.order,
                       {"roundtrip_byte_size": len(stream.getvalue())})
            roundtrip.close()
        except Exception:
            self.check("fonttools_save_reload", False, traceback.format_exc())
        self.stats.update({"font_path": str(self.path), "bytes": len(self.raw), "glyphs": len(self.order),
                           "cmap_codepoints": len(self.cmap), "units_per_em": self.upem,
                           "sha256": hashlib.sha256(self.raw).hexdigest(), "tables": sorted(self.font.keys())})

    def outlines_and_metrics(self):
        outline_errors, invalid_metrics, zero_printables, overflowing = [], [], [], []
        contour_errors = []
        from fontTools.pens.boundsPen import BoundsPen
        hmtx = self.font["hmtx"].metrics
        for name in self.order:
            try:
                self.glyphset[name].draw(RecordingPen())
                pen = BoundsPen(self.glyphset)
                self.glyphset[name].draw(pen)
                self.bounds[name] = pen.bounds
                if pen.bounds and not all(math.isfinite(v) for v in pen.bounds):
                    outline_errors.append({"glyph": name, "reason": "nonfinite_coordinates"})
                flattened = FlattenPen(self.glyphset)
                self.glyphset[name].draw(flattened)
                for index, contour in enumerate(flattened.contours):
                    polygon = Polygon(contour)
                    if not polygon.is_valid or polygon.area < 1:
                        contour_errors.append({"glyph": name, "contour": index,
                                               "reason": explain_validity(polygon), "area": polygon.area})
            except Exception as exc:
                outline_errors.append({"glyph": name, "reason": str(exc)})
            metrics = hmtx.get(name)
            if metrics is None or not (0 <= metrics[0] <= 65535 and -32768 <= metrics[1] <= 32767):
                invalid_metrics.append({"glyph": name, "hmtx": metrics})
        self.check("all_outlines_decompile_and_draw", not outline_errors, outline_errors)
        self.check("all_emitted_contours_have_simple_valid_geometry", not contour_errors, contour_errors)
        self.check("all_horizontal_metrics_valid", not invalid_metrics, invalid_metrics)
        for cp in list(range(0x21, 0x7F)) + CORE_ARABIC + list(range(0x0660, 0x066A)) + list(range(0x06F0, 0x06FA)):
            gn = self.cmap.get(cp)
            if gn and (hmtx[gn][0] <= 0 or not self.bounds.get(gn)):
                zero_printables.append({"codepoint": cp_label(cp), "glyph": gn})
        self.check("printable_base_glyphs_have_ink_and_advance", not zero_printables, zero_printables)
        os2 = self.font["OS/2"]
        hhea = self.font["hhea"]
        extrema = [b for b in self.bounds.values() if b]
        ink_min = min(b[1] for b in extrema) if extrema else 0
        ink_max = max(b[3] for b in extrema) if extrema else 0
        limits = {"hhea": [hhea.descent, hhea.ascent], "OS2_typo": [os2.sTypoDescender, os2.sTypoAscender],
                  "OS2_windows": [-os2.usWinDescent, os2.usWinAscent]}
        self.stats["line_metrics"] = {"unpositioned_ink_y_min": ink_min, "unpositioned_ink_y_max": ink_max,
                                       "limits": limits, "hhea_line_gap": hhea.lineGap, "typo_line_gap": os2.sTypoLineGap}
        for kind, (bottom, top) in limits.items():
            self.check("unpositioned_ink_inside_" + kind, ink_min >= bottom and ink_max <= top,
                       {"ink": [ink_min, ink_max], "line_limits": [bottom, top]})
        for name, b in self.bounds.items():
            if b and (b[0] < -100 or b[2] > hmtx[name][0] + 100) and hmtx[name][0] > 0:
                overflowing.append({"glyph": name, "bounds": b, "advance": hmtx[name][0]})
        self.check("large_horizontal_overhangs", not overflowing, overflowing, warning=True)

    def joining(self):
        beh = "ب"
        tests, missing_forms = [], []
        for cp in CORE_ARABIC:
            cases = [("isol", chr(cp), 0)]
            if cp in DUAL_JOINING:
                cases += [("init", chr(cp) + beh, 0), ("medi", beh + chr(cp) + beh, 1),
                          ("fina", beh + chr(cp), 1)]
            elif cp in RIGHT_JOINING:
                cases += [("fina", beh + chr(cp), 1), ("isol", chr(cp) + beh, 0)]
            else:
                cases += [("isol", beh + chr(cp) + beh, 1)]
            for form, text, cluster in cases:
                expected = self.glyph_form(cp, form)
                actual_shape = self.shape(text)
                actual = self.base_at_cluster(actual_shape, cluster)
                if expected is None:
                    missing_forms.append({"codepoint": cp_label(cp), "form": form})
                if actual != expected:
                    tests.append({"codepoint": cp_label(cp), "form": form, "text": text,
                                  "cluster": cluster, "expected": expected, "actual": actual,
                                  "shaped": actual_shape})
        self.check("required_Arabic_contextual_forms_exist", not missing_forms, missing_forms)
        self.check("core_Arabic_joining_behavior", not tests, tests)
        # Transparent fatha must preserve beh's connection across a mark.
        unmarked, marked = self.shape("بب"), self.shape("بَب")
        expected_names = [self.glyph_form(0x0628, "fina"), self.glyph_form(0x0628, "init")]
        mark_names = {self.cmap.get(cp) for cp in ARABIC_MARKS}
        bases_marked = [g["glyph"] for g in marked if g["glyph"] not in mark_names and g["x_advance"] != 0]
        self.check("marks_do_not_break_Arabic_joining", bases_marked == expected_names,
                   {"text": "بَب", "bases": bases_marked, "expected": expected_names})
        zwj = self.shape("ب\u200dب")
        zwnj = self.shape("ب\u200cب")
        zwj_bases = [g["glyph"] for g in zwj if g["glyph"] not in ("space", ".notdef") and g["x_advance"] > 0]
        zwnj_bases = [g["glyph"] for g in zwnj if g["glyph"] not in ("space", ".notdef") and g["x_advance"] > 0]
        self.check("ZWJ_preserves_connection", zwj_bases == expected_names,
                   {"text": "ب‍ب", "glyphs": zwj_bases, "expected": expected_names})
        self.check("ZWNJ_breaks_connection", zwnj_bases == [self.glyph_form(0x0628, "isol")]*2,
                   {"text": "ب‌ب", "glyphs": zwnj_bases})
        for text, cp, form, cluster in [("ب\u200d", 0x0628, "init", 0), ("\u200dب", 0x0628, "fina", 1)]:
            actual = self.base_at_cluster(self.shape(text), cluster)
            self.check("edge_ZWJ_"+form, actual == self.glyph_form(cp, form),
                       {"text": text, "actual": actual, "expected": self.glyph_form(cp, form)})
        self.stats["Arabic_contextual_form_cases"] = sum(4 if cp in DUAL_JOINING else 3 if cp in RIGHT_JOINING else 2
                                                         for cp in CORE_ARABIC)

    def joining_geometry(self):
        # Test the actual emitted outlines, not skeleton/control-point assertions.
        samples = ["ب" + chr(cp) + "ب" for cp in CORE_ARABIC]
        samples += ["علي", "عــــلــــي", "ع" + "ـ"*32 + "ل" + "ـ"*32 + "ي",
                    "ب" + "ـ"*64 + "ب", "تـصـويـر", "قـهـوة"]
        failures = []
        verified = 0
        tatweel = 0x0640
        for text in samples:
            cps = [ord(c) for c in text]
            shaped = self.shape(text)
            origins = {}
            pen_x = 0
            for g in shaped:
                if g["x_advance"] > 0:
                    origins[g["cluster"]] = (g, pen_x + g["x_offset"])
                pen_x += g["x_advance"]
            for index in range(len(cps)-1):
                can_join_forward = cps[index] in DUAL_JOINING or cps[index] == tatweel
                can_join_backward = cps[index+1] in DUAL_JOINING | RIGHT_JOINING or cps[index+1] == tatweel
                if not (can_join_forward and can_join_backward):
                    continue
                # Lam-alef ligature coalesces clusters and has no boundary to inspect.
                if index not in origins or index+1 not in origins:
                    continue
                right, right_x = origins[index]
                left, left_x = origins[index+1]
                right_ink = translate(self.geometry(right["glyph"]), xoff=right_x, yoff=right["y_offset"])
                left_ink = translate(self.geometry(left["glyph"]), xoff=left_x, yoff=left["y_offset"])
                boundary = (left_x + left["x_advance"] + right_x)/2
                window = box(boundary-80, 70-100, boundary+80, 70+100)
                distance = right_ink.intersection(window).distance(left_ink.intersection(window))
                if not math.isfinite(distance) or distance > 1.5:
                    failures.append({"text": text, "between": text[index:index+2],
                                     "glyphs": [left["glyph"], right["glyph"]],
                                     "boundary_x": boundary, "ink_distance": distance})
                verified += 1
        self.check("Arabic_baseline_ink_connections", not failures,
                   {"connection_boundaries_checked": verified, "failures": failures,
                    "method": "Flattened outline distance in a window around join baseline y=70; tolerance 1.5 font units."})

    def positioning(self):
        metrics = self.font["hmtx"].metrics
        mark_glyphs = {self.cmap[cp] for cp in ARABIC_MARKS if cp in self.cmap}
        bad = [{"glyph": gn, "advance": metrics[gn][0]} for gn in mark_glyphs if metrics[gn][0] != 0]
        self.check("Arabic_marks_zero_advance", not bad, bad)
        gdef = self.font["GDEF"].table if "GDEF" in self.font else None
        classdefs = getattr(getattr(gdef, "GlyphClassDef", None), "classDefs", {})
        bad_classes = [{"glyph": gn, "class": classdefs.get(gn)} for gn in mark_glyphs if classdefs.get(gn) != 3]
        self.check("Arabic_marks_GDEF_class_3", not bad_classes, bad_classes)
        feature_tags = {}
        for table_tag in ("GSUB", "GPOS"):
            table = self.font[table_tag].table if table_tag in self.font else None
            features = getattr(table, "FeatureList", None)
            feature_tags[table_tag] = sorted({r.FeatureTag for r in features.FeatureRecord}) if features else []
        self.stats["opentype_features"] = feature_tags
        self.check("Arabic_joining_feature_tags", {"init", "medi", "fina"}.issubset(set(feature_tags["GSUB"])), feature_tags["GSUB"])
        self.check("mark_positioning_feature", "mark" in feature_tags["GPOS"], feature_tags["GPOS"])
        self.check("mark_to_mark_positioning_feature", "mkmk" in feature_tags["GPOS"], feature_tags["GPOS"], warning=True)
        anchor_failures = []
        mark_classes = {}
        base_anchors = {}
        if "GPOS" in self.font and self.font["GPOS"].table.LookupList:
            for lookup in self.font["GPOS"].table.LookupList.Lookup:
                for sub in lookup.SubTable:
                    effective_type = lookup.LookupType
                    if effective_type == 9:
                        effective_type, sub = sub.ExtensionLookupType, sub.ExtSubTable
                    if effective_type == 4:
                        for name, record in zip(sub.MarkCoverage.glyphs, sub.MarkArray.MarkRecord):
                            mark_classes.setdefault(name, set()).add(record.Class)
                            if record.MarkAnchor is None:
                                anchor_failures.append({"mark": name, "reason": "missing_mark_anchor"})
                        for name, record in zip(sub.BaseCoverage.glyphs, sub.BaseArray.BaseRecord):
                            base_anchors.setdefault(name, set()).update(index for index, anchor in enumerate(record.BaseAnchor) if anchor is not None)
        expected_bases = set()
        for cp in CORE_ARABIC + [0x0640]:
            for suffix in ("isol", "init", "medi", "fina"):
                gn = self.glyph_form(cp, suffix)
                if gn:
                    expected_bases.add(gn)
        used_classes = set().union(*(mark_classes.get(name, set()) for name in mark_glyphs))
        for name in sorted(mark_glyphs):
            if not mark_classes.get(name):
                anchor_failures.append({"mark": name, "reason": "not_covered_by_mark_to_base_lookup"})
        for name in sorted(expected_bases):
            missing = used_classes - base_anchors.get(name, set())
            if missing:
                anchor_failures.append({"base": name, "missing_mark_classes": sorted(missing)})
        self.check("all_Arabic_forms_have_required_mark_anchors", not anchor_failures,
                   {"base_forms_checked": len(expected_bases), "mark_classes": sorted(used_classes), "failures": anchor_failures})
        # Verify marks are actually positioned, so unconnected feature tags cannot pass.
        positioning_failures = []
        for cp in ARABIC_MARKS:
            if cp not in self.cmap:
                continue
            text = "ب" + chr(cp)
            shaped = self.shape(text)
            records = [g for g in shaped if g["glyph"] == self.cmap[cp]]
            if len(records) != 1 or records[0]["x_advance"] != 0 or (records[0]["x_offset"] == 0 and records[0]["y_offset"] == 0):
                positioning_failures.append({"text": text, "glyph": self.cmap[cp], "shaped": shaped})
        self.check("every_core_mark_positioned_on_beh", not positioning_failures, positioning_failures)
        # Lam-alef is customary mandatory Arabic shaping; absence is surfaced explicitly.
        ligature_cases = []
        for text in ("لا", "لأ", "لإ", "لآ", "بلا", "بلأ", "بلإ", "بلآ"):
            shaped = self.shape(text)
            base_count = sum(g["x_advance"] > 0 for g in shaped)
            expected_count = 1 if len(text) == 2 else 2
            ligature_cases.append({"text": text, "pass": base_count == expected_count,
                                    "base_count": base_count, "glyphs": [g["glyph"] for g in shaped]})
        self.check("lam_alef_ligatures", all(x["pass"] for x in ligature_cases), ligature_cases,
                   warning="rlig" not in feature_tags["GSUB"])
        marked_ligature_cases = []
        for prefix in ("", "ب"):
            for alef in ("ا", "أ", "إ", "آ"):
                for marks in [chr(cp) for cp in ARABIC_MARKS] + ["َّ", "ِّ", "ُّ", "ٌّ", "ٍّ", "ّّ"]:
                    text = prefix + "ل" + marks + alef
                    shaped = self.shape(text)
                    base_count = sum(g["x_advance"] > 0 for g in shaped)
                    if base_count != 1 + len(prefix):
                        marked_ligature_cases.append({"text": text, "expected_base_count": 1+len(prefix),
                                                      "actual_base_count": base_count, "shaped": shaped})
        self.check("lam_alef_ignores_intervening_tashkeel", not marked_ligature_cases,
                   {"cases_checked": 2*4*(len(ARABIC_MARKS)+6), "failures": marked_ligature_cases})
        # Placed ink includes GPOS shifts, unlike bare glyph bounds.
        probes = ["مُصَوِّر", "عَلِيّ", "عَلِيٌّ", "شَدَّة", "قَهْوَةٌ", "بِسْمِ", "السَّلَامُ عَلَيْكُمْ", "اَللُّغَةُ الْعَرَبِيَّةُ",
                  "بَُِ", "بًّ", "بٌّ", "بٍّ", "بَّ", "بِّ", "بُّ", "بٰ", "لَا", "لَّأ", "لِّإ", "لُّآ", "بَلَّإ", "بّّ"]
        probes += ["عَــــلِــــيٌّ", "بَ" + "ـ"*64 + "بِّ"]
        line_overflow = []
        collisions = []
        win_bottom = -self.font["OS/2"].usWinDescent
        win_top = self.font["OS/2"].usWinAscent
        for text in probes:
            glyphs = self.shape(text)
            positioned_bounds = []
            pen_x = 0
            for g in glyphs:
                bound = self.bounds.get(g["glyph"])
                if bound:
                    placed = [bound[0]+pen_x+g["x_offset"], bound[1]+g["y_offset"],
                              bound[2]+pen_x+g["x_offset"], bound[3]+g["y_offset"]]
                    positioned_bounds.append({"glyph": g["glyph"], "bounds": placed,
                                              "is_mark": g["glyph"] in mark_glyphs})
                    if placed[1] < win_bottom or placed[3] > win_top:
                        line_overflow.append({"text": text, "glyph": g["glyph"], "bounds": placed,
                                              "windows_line_limits": [win_bottom, win_top]})
                pen_x += g["x_advance"]
            # Bounding-box mark/mark overlap is a conservative alert, not exact contour intersection.
            positioned_marks = [g for g in positioned_bounds if g["is_mark"]]
            for i, mark in enumerate(positioned_marks):
                for other in positioned_marks[i+1:]:
                    a, b = mark["bounds"], other["bounds"]
                    if min(a[2], b[2]) > max(a[0], b[0]) and min(a[3], b[3]) > max(a[1], b[1]):
                        collisions.append({"text": text, "marks": [mark["glyph"], other["glyph"]],
                                           "bounds": [a,b]})
            self.shaping.append({"text": text, "direction": "rtl", "glyphs": glyphs, "positioned_ink": positioned_bounds})
        self.check("marked_text_inside_windows_line_metrics", not line_overflow, line_overflow)
        self.check("mark_mark_bbox_overlap_alert", not collisions, collisions, warning=True)

    def representative_text(self):
        samples = [
            ("Arabic alphabet", "ءآأؤإئابتثجحخدذرزسشصضطظعغفقكلمنهوي", "rtl", "arab"),
            ("Arabic photo bio", "علي | أصوّر كل شيء: قهوة، ألعاب، سيارات وطبيعة.", "rtl", "arab"),
            ("Arabic grammar and marks", "إِنَّ اللُّغَةَ الْعَرَبِيَّةَ جَمِيلَةٌ؛ لَا مَشَاكِلَ؟", "rtl", "arab"),
            ("Arabic digits", "٠١٢٣٤٥٦٧٨٩ ۰۱۲۳۴۵۶۷۸۹ 1234567890 ٪٫٬", "rtl", "arab"),
            ("Arabic tatweel", "عــلــي تـصـويـر", "rtl", "arab"),
            ("Arabic long tatweel", "ع" + "ـ"*32 + "ل" + "ـ"*32 + "ي", "rtl", "arab"),
            ("Arabic repeated marks", "بّّ بََ بَّ بُّ بِّ لَّأ", "rtl", "arab"),
            ("Latin mixed case", "ALY ali Aly | Photography, Gaming & Coffee", "ltr", "latn"),
            ("Latin alphabet", "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz", "ltr", "latn"),
            ("ASCII digits and punctuation", "0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", "ltr", "latn"),
        ]
        failed = []
        for label, text, direction, script in samples:
            shaped = self.shape(text, direction, script)
            if not shaped or any(g["gid"] == 0 for g in shaped):
                failed.append({"sample": label, "text": text, "glyphs": shaped})
            self.shaping.append({"label": label, "text": text, "direction": direction, "script": script, "glyphs": shaped})
        self.check("representative_text_no_notdef", not failed, failed)
        # A font shaper is not a Unicode BiDi paragraph layout engine. Mixed scripts are
        # therefore tested as independently shaped runs, the way normal apps consume them.
        self.stats["mixed_direction_test"] = "Arabic/Latin/number runs shaped independently; full paragraph BiDi belongs to the host app."

    def run(self):
        for stage in (self.structure, self.outlines_and_metrics, self.joining, self.joining_geometry, self.positioning, self.representative_text):
            try:
                stage()
            except Exception:
                self.check(stage.__name__+"_completed", False, traceback.format_exc())
        return {"font": str(self.path), "status": "fail" if self.errors else "pass_with_warnings" if self.warnings else "pass",
                "errors": self.errors, "warnings": self.warnings, "checks": self.checks,
                "statistics": self.stats, "shaping_samples": self.shaping,
                "limits": ["Automated checks cover the listed Unicode characters and sample strings, not all Unicode.",
                           "Physical-device installation and behavior in every app require device testing.",
                           "Mark overlap alerts use bounding boxes and may be intentional; visually inspect the specimen.",
                           "Long repeated combining-mark sequences can exceed finite line metrics.",
                           "No claim of zero possible defects is made."]}


def main():
    if len(sys.argv) not in (2, 3):
        raise SystemExit("Usage: python validate_font.py font.ttf [report.json]")
    try:
        report = FontQA(sys.argv[1]).run()
    except Exception:
        report = {"font": sys.argv[1], "status": "fail", "errors": [{"check": "font_load", "details": traceback.format_exc()}]}
    encoded = json.dumps(report, ensure_ascii=False, indent=2)
    if len(sys.argv) == 3:
        target = Path(sys.argv[2])
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(encoded + "\n", encoding="utf-8")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass
    print(encoded)
    raise SystemExit(1 if report["status"] == "fail" else 0)


if __name__ == "__main__":
    main()
