"""ALY Scribble — original open-source marker font builder.
Copyright 2026 The ALY Project Authors. SIL Open Font License 1.1.
"""
from pathlib import Path
import sys, math, hashlib, json, unicodedata, copy
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.t2CharStringPen import T2CharStringPen
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
from fontTools.ttLib import TTFont
from shapely.geometry import LineString,Point,Polygon
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from shapely import set_precision
import latin_design, arabic_design

OUT=HERE.parent if HERE.name=='source' else HERE.parents[1]/'outputs'/'ALY-Scribble';OUT.mkdir(parents=True,exist_ok=True)
SOURCES=OUT/'source';SOURCES.mkdir(exist_ok=True)
def path(a,*commands):return arabic_design.path(a,*commands)
def g(width,strokes=(),dots=(),anchors=None):return {'width':width,'strokes':list(strokes),'dots':list(dots),'anchors':anchors or {}}

def design():
    glyphs={'.notdef':g(650,[[(90,0),(90,660),(550,660),(550,0),(90,0)],[(140,80),(500,580)],[(140,580),(500,80)]]),
            'space':g(320),'zero':g(0)}
    cmap={0x20:'space',0xA0:'space',0x200C:'zero',0x200D:'zero',0x200E:'zero',0x200F:'zero',0xFEFF:'zero',0x2060:'zero',0x061C:'zero',0x200B:'zero'}
    for cp,v in latin_design.get_glyphs().items():
        if cp==32:continue
        name=f'uni{cp:04X}';glyphs[name]=v;cmap[cp]=name
    glyphs.update(arabic_design.get_glyphs());cmap.update(arabic_design.cmap())
    # Harakat are centered on an attachment origin, with true zero advance.
    marks={
      0x064E:g(0,[[( -70,15),(70,56)]]),
      0x0650:g(0,[[(-70,-14),(70,-54)]]),
      0x064B:g(0,[[(-70,10),(70,51)],[(-70,105),(70,146)]]),
      0x064D:g(0,[[(-70,-10),(70,-51)],[(-70,-105),(70,-146)]]),
      0x064F:g(0,[path((13,6),('Q',(-90,45),(-41,101)),('Q',(1,156),(53,108)),('Q',(86,53),(13,62)),('Q',(-31,26),(-48,-1)))]),
      0x064C:g(0,[path((-24,4),('Q',(-103,47),(-65,99)),('Q',(-25,136),(13,94)),('Q',(40,49),(-24,58))),path((68,0),('Q',(-11,43),(27,95)),('Q',(68,132),(106,90)),('Q',(131,45),(68,54)))]),
      0x0651:g(0,[path((-88,62),('Q',(-97,-10),(-42,7)),('Q',(-9,14),(-20,57)),('Q',(-10,-9),(39,7)),('Q',(78,14),(76,71)))]),
      0x0652:g(0,[[(math.cos(i*2*math.pi/40)*48,55+math.sin(i*2*math.pi/40)*48) for i in range(41)]]),
      0x0653:g(0,[path((-103,31),('Q',(-57,93),(-8,44)),('Q',(44,-5),(106,58)))]),
      0x0654:g(0,[path((58,82),('Q',(-29,129),(-54,63)),('Q',(-45,21),(33,20)),('L',(-65,-14)))]),
      0x0655:g(0,[path((58,-27),('Q',(-29,20),(-54,-46)),('Q',(-45,-88),(33,-89)),('L',(-65,-123)))]),
      0x0670:g(0,[[(-4,0),(5,133)]]),
      0x0656:g(0,[[(-4,0),(5,-133)]]),
      0x0657:g(0,[path((0,0),('Q',(-62,53),(0,105)),('Q',(62,53),(0,0)))]),
    }
    for cp,v in marks.items():name=f'mark{cp:04X}';glyphs[name]=v;cmap[cp]=name
    # Useful Urdu full stop, direction-neutral mirrored punctuation and basic symbols.
    glyphs['uni06D4']=g(280,[[ (65,35),(195,35) ]]);cmap[0x06D4]='uni06D4'
    circle=[(300+200*math.cos(i*2*math.pi/32),310+200*math.sin(i*2*math.pi/32),24) for i in range(0,32,4)]
    glyphs['dottedcircle']=g(600,dots=circle,anchors={'top':(300,665),'bottom':(300,-115)});cmap[0x25CC]='dottedcircle'
    # Four mandatory lam-alef variants, isolated and right-connected final.
    for cp in [0x0627,0x0622,0x0623,0x0625]:
      for final in [False,True]:
        nm=f'lamalef{cp:04X}'+('.fina' if final else '')
        ss=[path((197,647),('Q',(190,507),(309,276)),('Q',(429,81),(401,-41)),('Q',(306,-152),(147,-67)),('Q',(83,-25),(97,71))),path((489,656),('Q',(407,382),(163,43)))]
        if final:ss.append(path((650,70),('Q',(500,70),(403,99))))
        if cp==0x0622:ss.append(path((367,761),('Q',(422,820),(477,772)),('Q',(518,737),(565,785))))
        if cp==0x0623:ss.append(path((542,802),('Q',(454,849),(429,783)),('Q',(438,741),(516,740)),('L',(418,706))))
        if cp==0x0625:ss.append(path((216,-189),('Q',(128,-142),(103,-208)),('Q',(112,-250),(190,-251)),('L',(92,-285))))
        glyphs[nm]=g(650,ss,anchors={'top':(325,920 if cp in [0x0622,0x0623] else 760),'bottom':(260,-420 if cp==0x0625 else -220)})
    # Presentation forms map to the actual contextual glyphs, for legacy input.
    for cp in range(0xFB50,0xFF00):
      if not unicodedata.name(chr(cp),'').startswith('ARABIC'):continue
      decomp=unicodedata.normalize('NFKC',chr(cp));label=unicodedata.name(chr(cp),'')
      form=next((s for s in ['ISOLATED','INITIAL','MEDIAL','FINAL'] if s in label),'')
      suffix={'ISOLATED':'','INITIAL':'.init','MEDIAL':'.medi','FINAL':'.fina'}.get(form,'')
      if len(decomp)==1 and ord(decomp) in arabic_design.cmap():
        nm=arabic_design.cmap()[ord(decomp)]+suffix
        if nm in glyphs:cmap[cp]=nm
      elif len(decomp)==2 and decomp[0]=='ل' and ord(decomp[1]) in [0x0622,0x0623,0x0625,0x0627]:
        cmap[cp]=f'lamalef{ord(decomp[1]):04X}'+('.fina' if form=='FINAL' else '')
    return glyphs,cmap,marks

def outline(v,name,weight):
    if name.startswith('mark'):
      weight=weight*.62
    seed=int(hashlib.sha256(name.encode()).hexdigest()[:8],16)
    pieces=[]
    for si,stroke in enumerate(v.get('strokes',[])):
      if len(stroke)<2:continue
      # Resample long straight strokes, retaining all authored endpoints.
      pts=[stroke[0]]
      for a,b in zip(stroke,stroke[1:]):
        distance=math.hypot(b[0]-a[0],b[1]-a[1]);n=max(1,math.ceil(distance/22))
        pts.extend((a[0]+(b[0]-a[0])*i/n,a[1]+(b[1]-a[1])*i/n) for i in range(1,n+1))
      altered=[];radii=[]
      for i,p in enumerate(pts):
        # Uniform nib at the exact joins; hand variation elsewhere is deterministic.
        joining=(name.startswith('ar') and abs(p[1]-70)<1 and (abs(p[0])<1 or abs(p[0]-v['width'])<1))
        phase=(seed%100)*.13+si
        env=min(1,i/3,(len(pts)-1-i)/3)
        altered.append((p[0]+env*2.7*math.sin(i*.71+phase),p[1]+env*2.7*math.cos(i*.64+phase)))
        radii.append(weight/2 if joining else weight/2*(1+.085*math.sin(i*.31+phase)))
      for i,(a,b) in enumerate(zip(altered,altered[1:])):
        r=(radii[i]+radii[i+1])/2
        if a!=b:pieces.append(LineString([a,b]).buffer(r,quad_segs=6))
    for x,y,r in v.get('dots',[]):pieces.append(Point(x,y).buffer(r*(weight/56)**.28,quad_segs=12))
    if not pieces:return []
    geo=set_precision(unary_union(pieces).buffer(0).simplify(.65,preserve_topology=True),1,mode='valid_output')
    polygons=[geo] if geo.geom_type=='Polygon' else list(geo.geoms)
    contours=[]
    for poly in polygons:
      poly=orient(poly,sign=-1)
      for ring in [poly.exterior,*poly.interiors]:
        points=[]
        for x,y in list(ring.coords)[:-1]:
          p=(round(x),round(y))
          if not points or points[-1]!=p:points.append(p)
        if len(points)>2:contours.append(points)
    return contours

def features(glyphs,marks,contours):
    lines=['languagesystem DFLT dflt;','languagesystem latn dflt;','languagesystem arab dflt;','languagesystem arab ARA;','languagesystem arab URD;','languagesystem arab FAR;']
    for suffix in ['init','medi','fina']:
      lines.append(f'feature {suffix} {{')
      for cp,nm in arabic_design.cmap().items():
        if nm+'.'+suffix in glyphs:lines.append(f' sub {nm} by {nm}.{suffix};')
      lines.append(f'}} {suffix};')
    lines+=['feature rlig {',' lookupflag IgnoreMarks;']
    for cp in [0x0627,0x0622,0x0623,0x0625]:
      alef=f'ar{cp:04X}.fina'; lig=f'lamalef{cp:04X}'
      lines.append(f' sub ar0644.init {alef} by {lig};')
      lines.append(f' sub ar0644.medi {alef} by {lig}.fina;')
    lines+=['} rlig;']
    bottom={0x064D,0x0650,0x0655,0x0656}
    for cp in marks:lines.append(f'markClass mark{cp:04X} <anchor 0 0> @'+('BOTTOM;' if cp in bottom else 'TOP;'))
    lines+=['feature mark {',' lookupflag 0;']
    for nm,v in glyphs.items():
      if nm.startswith('mark') or not contours[nm]:continue
      pts=[p for c in contours[nm] for p in c]
      top=max(p[1] for p in pts);bot=min(p[1] for p in pts);w=v['width']
      anchors=v.get('anchors',{})
      ax,ay=anchors.get('top',(round(w/2),top+95))
      bx,by=anchors.get('bottom',(round(w/2),bot-85))
      ay=max(ay,top+70);by=min(by,bot-70)
      if nm.startswith('lamalef'):
        lines.append(f' pos ligature {nm} <anchor 200 800> mark @TOP <anchor 200 -220> mark @BOTTOM ligComponent <anchor 490 {round(ay)}> mark @TOP <anchor 160 {round(by)}> mark @BOTTOM;')
      else:
        lines.append(f' pos base {nm} <anchor {round(ax)} {round(ay)}> mark @TOP <anchor {round(bx)} {round(by)}> mark @BOTTOM;')
    lines+=['} mark;','feature mkmk {',' lookupflag 0;']
    for cp in marks:
      nm=f'mark{cp:04X}';pts=[p for c in contours[nm] for p in c]
      if cp in bottom:
        lines.append(f' pos mark {nm} <anchor 0 {min(p[1] for p in pts)-80}> mark @BOTTOM;')
      else:lines.append(f' pos mark {nm} <anchor 0 {max(p[1] for p in pts)+80}> mark @TOP;')
    lines+=['} mkmk;','feature kern {',' script latn;']
    cm={cp:f'uni{cp:04X}' for cp in latin_design.get_glyphs() if cp!=32}
    for pair,val in {'AV':-45,'AW':-35,'AY':-40,'VA':-45,'WA':-35,'YA':-45,'To':-40,'Ta':-35,'Te':-35,'Yo':-40,'Vo':-25,'LT':-25,'fa':-10}.items():
      a,b=pair;lines.append(f' pos {cm[ord(a)]} {cm[ord(b)]} {val};')
    lines+=['} kern;']
    return '\n'.join(lines)

def build(weight=56,style='Regular'):
    designs,cmap,marks=design();names=list(designs);geometries={nm:outline(v,nm,weight) for nm,v in designs.items()}
    metrics={nm:(v['width'],min([p[0] for c in geometries[nm] for p in c],default=0)) for nm,v in designs.items()}
    allpts=[p for cs in geometries.values() for c in cs for p in c]
    ytop=max(p[1] for p in allpts);ybot=min(p[1] for p in allpts)
    fea=features(designs,marks,geometries)
    (SOURCES/f'features-{style}.fea').write_text(fea,encoding='utf-8')
    for isttf in [True,False]:
      fb=FontBuilder(1000,isTTF=isttf);fb.setupGlyphOrder(names);fb.setupCharacterMap(cmap)
      if isttf:
        gs={}
        for nm,cs in geometries.items():
          pen=TTGlyphPen(None)
          for c in cs:
            pen.moveTo(c[0])
            for p in c[1:]:pen.lineTo(p)
            pen.closePath()
          gs[nm]=pen.glyph()
        fb.setupGlyf(gs)
      else:
        csdict={}
        for nm,cs in geometries.items():
          pen=T2CharStringPen(designs[nm]['width'],None)
          for c in cs:
            pen.moveTo(c[0])
            for p in c[1:]:pen.lineTo(p)
            pen.closePath()
          csdict[nm]=pen.getCharString()
        fb.setupCFF('ALYScribble-'+style,{'FullName':'ALY Scribble '+style,'FamilyName':'ALY Scribble','Weight':style},csdict,{})
      fb.setupHorizontalMetrics(metrics)
      fb.setupHorizontalHeader(ascent=1250,descent=-720,lineGap=0)
      fb.setupNameTable({'familyName':'ALY Scribble','styleName':style,'uniqueFontIdentifier':'ALY Scribble '+style+' 1.000','fullName':'ALY Scribble '+style,'psName':'ALYScribble-'+style,'version':'Version 1.000','copyright':'Copyright 2026 The ALY Project Authors.','description':'Original Arabic and English handwritten marker typeface. Includes Arabic joining, diacritics, tatweel and three numeral sets.','licenseDescription':'Licensed under the SIL Open Font License, Version 1.1.','licenseInfoURL':'https://openfontlicense.org','manufacturer':'The ALY Project','designer':'ALY Project Authors'})
      fb.setupOS2(sTypoAscender=1250,sTypoDescender=-720,sTypoLineGap=0,usWinAscent=1600,usWinDescent=900,usWeightClass=400 if style=='Regular' else 700,fsType=0,sxHeight=460,sCapHeight=660,fsSelection=0x40 if style=='Regular' else 0x20)
      fb.setupPost();fb.setupMaxp();fb.font['head'].macStyle=0 if style=='Regular' else 1
      addOpenTypeFeaturesFromString(fb.font,fea)
      filename=OUT/('ALYScribble-'+style+('.ttf' if isttf else '.otf'))
      fb.save(filename)
      if isttf:
        w=TTFont(filename);w.flavor='woff2';w.save(OUT/f'ALYScribble-{style}.woff2')
    (SOURCES/f'outline-{style}.json').write_text(json.dumps({'glyphs':designs,'cmap':cmap},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    return {'style':style,'glyphs':len(names),'characters':len(cmap),'bounds':[ytop,ybot]}

if __name__=='__main__':
    print(json.dumps([build(56,'Regular'),build(72,'Bold')],ensure_ascii=False))
