"""Original Arabic marker skeletons for ALY Scribble.

The curves in this source were drawn expressly for this project.  No existing
font outlines are used.  Coordinates use a 1000-unit em and a baseline join
height of 70.  A stroke is a sampled centre line; the font builder supplies
the round, slightly uneven ink outline.
"""
from copy import deepcopy
from math import hypot

JOIN = 70
DOT_RADIUS = 36


def path(start, *commands):
    """Sample original quadratic/cubic pen movements into a polyline."""
    out = [tuple(start)]
    for command in commands:
        kind, *args = command
        a = out[-1]
        if kind == "L":
            out.append(tuple(args[0]))
            continue
        if kind == "Q":
            b, c = args
            count = max(6, min(20, int((hypot(b[0]-a[0], b[1]-a[1]) +
                                       hypot(c[0]-b[0], c[1]-b[1])) / 26)))
            for i in range(1, count + 1):
                t = i / count
                s = 1 - t
                out.append((s*s*a[0] + 2*s*t*b[0] + t*t*c[0],
                            s*s*a[1] + 2*s*t*b[1] + t*t*c[1]))
        elif kind == "C":
            b, c, d = args
            count = max(8, min(28, int((hypot(b[0]-a[0], b[1]-a[1]) +
                                       hypot(c[0]-b[0], c[1]-b[1]) +
                                       hypot(d[0]-c[0], d[1]-c[1])) / 26)))
            for i in range(1, count + 1):
                t = i / count
                s = 1 - t
                out.append((s*s*s*a[0] + 3*s*s*t*b[0] + 3*s*t*t*c[0] + t*t*t*d[0],
                            s*s*s*a[1] + 3*s*s*t*b[1] + 3*s*t*t*c[1] + t*t*t*d[1]))
        else:
            raise ValueError(kind)
    return out


def L(p): return ("L", p)
def Q(a, b): return ("Q", a, b)
def C(a, b, c): return ("C", a, b, c)


def glyph(width, strokes, dots=(), anchor_x=None, top=None, bottom=None):
    all_points = [p for stroke in strokes for p in stroke]
    xs = [p[0] for p in all_points]
    ys = [p[1] for p in all_points]
    ys += [y+r for x, y, r in dots] + [y-r for x, y, r in dots]
    if anchor_x is None:
        anchor_x = (min(xs) + max(xs))/2
    if top is None: top = max(ys) + 105
    if bottom is None: bottom = min(ys) - 90
    return {"width": int(width), "strokes": strokes, "dots": list(dots),
            "anchors": {"top": (int(anchor_x), int(top)),
                        "bottom": (int(anchor_x), int(bottom))}}


def dot(x, y): return (x, y, DOT_RADIUS)


def translated(stroke, dx=0, dy=0):
    return [(x+dx, y+dy) for x,y in stroke]


def _build():
    result = {}
    unicode_map = {}
    joins = {}

    def add(cp, forms, joining="dual"):
        name = f"ar{cp:04X}"
        unicode_map[cp] = name
        joins[cp] = joining
        for form, data in forms.items():
            result[name if form == "isol" else name + "." + form] = deepcopy(data)

    def family(cp, forms, dots_by_form, joining="dual"):
        decorated = deepcopy(forms)
        for form, data in decorated.items():
            data["dots"] = list(dots_by_form.get(form, ()))
            if data["dots"]:
                highest = max(y+r for x,y,r in data["dots"])
                data["anchors"]["top"] = (data["anchors"]["top"][0],
                                             max(data["anchors"]["top"][1], int(highest+100)))
                lowest = min(y-r for x,y,r in data["dots"])
                data["anchors"]["bottom"] = (data["anchors"]["bottom"][0],
                                                min(data["anchors"]["bottom"][1], int(lowest-90)))
        add(cp, decorated, joining)

    # Ba family: an open flat bowl and a distinctive rounded joining tooth.
    ba = {
        "isol": glyph(570, [path((490,235), Q((512,93),(455,36)),
                     C((392,-10),(205,-23),(120,8)), Q((61,35),(77,197)))], anchor_x=280),
        "init": glyph(285, [path((220,248), Q((239,132),(196,89)),
                     Q((172,70),(0,70)))], anchor_x=155),
        "medi": glyph(290, [path((290,70), L((223,70)),
                     Q((204,89),(197,164)), Q((188,248),(166,235)),
                     Q((149,127),(125,89)), Q((102,70),(0,70)))], anchor_x=170),
        "fina": glyph(610, [path((610,70), L((520,70)),
                     Q((500,6),(446,-8)), C((348,-40),(198,-32),(119,0)),
                     Q((63,25),(77,215)))], anchor_x=285)
    }
    family(0x0628, ba, {"isol":[dot(283,-106)], "init":[dot(153,-47)],
                       "medi":[dot(156,-47)], "fina":[dot(282,-119)]})
    family(0x062A, ba, {"isol":[dot(241,304),dot(325,304)],
                       "init":[dot(122,349),dot(206,349)],
                       "medi":[dot(124,349),dot(208,349)],
                       "fina":[dot(241,306),dot(325,306)]})
    family(0x062B, ba, {"isol":[dot(241,304),dot(325,304),dot(283,383)],
                       "init":[dot(122,344),dot(206,344),dot(164,423)],
                       "medi":[dot(124,344),dot(208,344),dot(166,423)],
                       "fina":[dot(241,304),dot(325,304),dot(283,383)]})
    family(0x067E, ba, {"isol":[dot(241,-107),dot(325,-107),dot(283,-186)],
                       "init":[dot(112,-43),dot(196,-43),dot(154,-122)],
                       "medi":[dot(114,-43),dot(198,-43),dot(156,-122)],
                       "fina":[dot(240,-120),dot(324,-120),dot(282,-199)]})

    # Alif: a long pen movement with a subtle forward lean at the foot.
    alif = {
        "isol": glyph(245,[path((130,653), Q((111,375),(141,86)), L((160,53)))],anchor_x=130),
        "fina": glyph(250,[path((127,653), Q((109,384),(140,114)),
                     Q((149,70),(184,70)), L((250,70)))],anchor_x=130)
    }
    add(0x0627, alif, "right")

    # Hamza is an original open curl, intentionally broad enough at small size.
    hamza = path((240,340), Q((183,384),(125,340)), Q((86,303),(115,265)),
                 Q((160,231),(230,249)), Q((150,220),(92,179)))
    add(0x0621,{"isol":glyph(325,[hamza],anchor_x=169)},"none")

    def hamza_at(cx, baseline):
        return translated(path((88,40),Q((38,76),(-8,43)),Q((-40,12),(-15,-15)),
                               Q((17,-42),(78,-25)),Q((14,-52),(-36,-77))),cx,baseline)

    for cp, accent_kind in ((0x0622,"madda"),(0x0623,"above"),(0x0625,"below"),(0x0671,"wasla")):
        fs = deepcopy(alif)
        for form,g in fs.items():
            if accent_kind == "madda":
                g["strokes"].append(path((50,782),Q((88,839),(137,801)),
                                          Q((168,771),(223,811))))
                g["anchors"]["top"]=(136,910)
            elif accent_kind == "above":
                g["strokes"].append(hamza_at(120,785));g["anchors"]["top"]=(130,951)
            elif accent_kind == "below":
                g["strokes"].append(hamza_at(120,-98));g["anchors"]["bottom"]=(130,-260)
            else:
                g["strokes"].append(path((52,760),Q((104,805),(141,785)),
                                          Q((187,761),(209,803)),L((62,751))))
                g["anchors"]["top"]=(130,906)
        add(cp,fs,"right")

    # Jim / ha / kha: a sloping open head and a generously curved lower bowl.
    ha = {
        "isol":glyph(535,[path((441,358),Q((386,410),(260,356)),
                      Q((191,332),(159,291)), Q((241,259),(354,239)),
                      Q((385,223),(335,111)), C((287,31),(116,8),(94,-94)),
                      C((75,-198),(249,-228),(391,-160)))],anchor_x=285),
        "init":glyph(420,[path((350,360),Q((284,405),(181,353)),
                      Q((130,325),(111,297)),Q((221,261),(325,231)),
                      Q((292,104),(211,83)),Q((146,70),(0,70)))],anchor_x=246),
        "medi":glyph(455,[path((455,70),L((354,70)),Q((336,87),(343,180)),
                      Q((328,329),(215,357)),Q((153,352),(113,296)),
                      Q((224,253),(314,225)),Q((270,91),(174,76)),L((0,70)))],anchor_x=235),
        "fina":glyph(580,[path((580,70),L((453,70)),Q((422,98),(433,192)),
                      Q((420,324),(298,357)),Q((210,351),(160,294)),
                      Q((244,260),(362,228)),Q((370,160),(308,73)),
                      C((226,5),(88,-27),(100,-126)),
                      C((112,-220),(260,-227),(403,-163)))],anchor_x=286)
    }
    add(0x062D,ha)
    family(0x062C,ha,{"isol":[dot(255,-82)],"init":[dot(236,-44)],
                     "medi":[dot(222,-48)],"fina":[dot(259,-78)]})
    family(0x062E,ha,{"isol":[dot(313,484)],"init":[dot(270,489)],
                     "medi":[dot(256,483)],"fina":[dot(299,483)]})
    family(0x0686,ha,{"isol":[dot(211,-67),dot(295,-67),dot(253,-146)],
                     "init":[dot(194,-41),dot(278,-41),dot(236,-120)],
                     "medi":[dot(180,-41),dot(264,-41),dot(222,-120)],
                     "fina":[dot(217,-68),dot(301,-68),dot(259,-147)]})

    # Dal and ra keep their non-joining left tails separate and unmistakable.
    dal = {
        "isol":glyph(365,[path((166,370),Q((281,309),(284,201)),
                         Q((280,90),(225,57)),Q((167,27),(81,48)))],anchor_x=188),
        "fina":glyph(425,[path((175,370),Q((285,313),(292,207)),
                         Q((292,102),(241,72)),Q((168,33),(82,51))),
                         path((425,70),L((254,70)))],anchor_x=202)
    }
    add(0x062F,dal,"right")
    family(0x0630,dal,{"isol":[dot(216,488)],"fina":[dot(224,488)]},"right")
    ra = {
        "isol":glyph(330,[path((248,281),Q((267,125),(225,-6)),
                         Q((170,-157),(72,-184)),L((43,-157)))],anchor_x=217),
        "fina":glyph(400,[path((252,278),Q((276,105),(231,-16)),
                         Q((176,-168),(64,-195))),path((400,70),L((258,70)))],anchor_x=225)
    }
    add(0x0631,ra,"right")
    family(0x0632,ra,{"isol":[dot(249,396)],"fina":[dot(250,393)]},"right")
    family(0x0698,ra,{"isol":[dot(207,394),dot(291,394),dot(249,473)],
                     "fina":[dot(208,394),dot(292,394),dot(250,473)]},"right")

    # Sin: three lively but separated teeth, not a wavy baseline substitute.
    seen = {
        "init":glyph(525,[path((465,238),Q((477,128),(421,92)),
                      Q((376,75),(363,210)),Q((344,246),(326,199)),
                      Q((322,100),(279,87)),Q((239,81),(230,215)),
                      Q((211,242),(195,192)),Q((190,79),(137,73)),L((0,70)))],anchor_x=310),
        "medi":glyph(550,[path((550,70),L((487,70)),Q((474,96),(466,189)),
                      Q((458,242),(432,215)),Q((418,94),(376,83)),
                      Q((346,83),(340,207)),Q((321,242),(304,191)),
                      Q((302,95),(258,82)),Q((227,88),(221,217)),
                      Q((200,246),(184,189)),Q((181,79),(135,73)),L((0,70)))],anchor_x=313),
        "isol":glyph(735,[path((654,233),Q((667,116),(605,90)),
                      Q((566,87),(555,208)),Q((536,244),(518,188)),
                      Q((519,96),(471,80)),Q((434,82),(426,211)),
                      Q((405,245),(389,181)),Q((388,29),(339,-95)),
                      C((296,-197),(152,-217),(83,-120)),Q((50,-48),(73,170)))],anchor_x=440),
        "fina":glyph(770,[path((770,70),L((700,70)),Q((681,115),(677,195)),
                      Q((667,242),(642,218)),Q((631,91),(587,85)),
                      Q((552,86),(548,213)),Q((530,244),(511,190)),
                      Q((508,88),(464,81)),Q((429,86),(425,212)),
                      Q((404,245),(388,181)),Q((389,17),(338,-104)),
                      C((291,-200),(146,-215),(80,-117)),Q((49,-45),(73,173)))],anchor_x=443)
    }
    add(0x0633,seen)
    family(0x0634,seen,{f:[dot(x-42,338),dot(x+42,338),dot(x,417)]
                         for f,x in (("init",338),("medi",330),("isol",521),("fina",526))})

    # Sad: a closed broad counter, one shoulder tooth, then the open bowl.
    sad = {
        "init":glyph(555,[path((442,76),C((518,129),(511,257),(430,308)),
                      C((356,352),(260,281),(242,180)),Q((225,86),(285,76)),
                      Q((367,60),(442,76))),path((284,76),L((234,70)),
                      Q((223,83),(206,158)),Q((194,187),(177,154)),
                      Q((162,79),(133,73)),L((0,70)))],anchor_x=351),
        "medi":glyph(605,[path((605,70),L((450,70))),
                      path((443,76),C((518,128),(513,259),(430,309)),
                      C((355,350),(260,281),(242,180)),Q((225,86),(285,76)),
                      Q((367,60),(443,76))),path((284,76),L((234,70)),
                      Q((224,85),(206,158)),Q((194,187),(177,154)),
                      Q((162,79),(133,73)),L((0,70)))],anchor_x=354),
        "isol":glyph(735,[path((612,76),C((688,128),(682,257),(600,308)),
                      C((526,351),(430,281),(412,180)),Q((396,86),(455,76)),
                      Q((537,60),(612,76))),path((454,76),L((399,70)),
                      Q((388,87),(376,157)),Q((361,192),(344,151)),
                      Q((331,-12),(287,-102)),C((242,-185),(130,-192),(79,-116)),
                      Q((50,-44),(70,168)))],anchor_x=520),
        "fina":glyph(790,[path((790,70),L((621,70))),
                      path((612,76),C((688,128),(682,257),(600,308)),
                      C((526,351),(430,281),(412,180)),Q((396,86),(455,76)),
                      Q((537,60),(612,76))),path((454,76),L((399,70)),
                      Q((388,87),(376,157)),Q((361,192),(344,151)),
                      Q((331,-12),(287,-102)),C((242,-185),(130,-192),(79,-116)),
                      Q((50,-44),(70,168)))],anchor_x=520)
    }
    add(0x0635,sad)
    family(0x0636,sad,{"init":[dot(385,438)],"medi":[dot(385,438)],
                     "isol":[dot(554,438)],"fina":[dot(554,438)]})

    # Tah has a conspicuous tall upright crossing the broad rounded counter.
    tah_loop = path((431,77),C((512,103),(500,255),(408,296)),
                    C((316,336),(203,247),(168,134)),Q((145,75),(231,71)),
                    Q((352,62),(431,77)))
    tah_stem = path((343,651),Q((326,366),(346,106)))
    tah = {
        "isol":glyph(550,[tah_loop,tah_stem],anchor_x=345),
        "init":glyph(540,[tah_loop,tah_stem,path((185,79),Q((142,70),(0,70)))],anchor_x=345),
        "medi":glyph(580,[tah_loop,tah_stem,path((580,70),L((437,70))),
                           path((185,79),Q((142,70),(0,70)))],anchor_x=345),
        "fina":glyph(605,[tah_loop,tah_stem,path((605,70),L((437,70)))],anchor_x=345)
    }
    add(0x0637,tah)
    family(0x0638,tah,{f:[dot(448,436)] for f in tah})

    # Ayn initial is open; its medial form has the compact triangular counter.
    ayn = {
        "init":glyph(420,[path((343,364),Q((275,407),(195,361)),
                      Q((135,315),(169,249)),Q((189,211),(300,162)),
                      Q((294,92),(223,77)),L((0,70)))],anchor_x=245),
        "medi":glyph(430,[path((430,70),L((281,70))),
                      path((182,76),Q((279,107),(301,187)),
                      Q((321,250),(252,288)),Q((171,266),(128,188)),
                      Q((109,116),(182,76))),path((182,76),Q((96,70),(0,70)))],anchor_x=218),
        "isol":glyph(525,[path((392,365),Q((318,415),(235,365)),
                      Q((173,320),(204,255)),Q((224,213),(331,166)),
                      Q((325,93),(229,23)),C((151,-22),(93,-103),(132,-171)),
                      C((170,-237),(314,-238),(411,-168)))],anchor_x=269),
        "fina":glyph(580,[path((580,70),L((405,70)),Q((368,76),(332,165))),
                      path((392,365),Q((318,415),(235,365)),
                      Q((173,320),(204,255)),Q((224,213),(332,165)),
                      Q((325,93),(229,23)),C((151,-22),(93,-103),(132,-171)),
                      C((170,-237),(314,-238),(411,-168)))],anchor_x=269)
    }
    add(0x0639,ayn)
    family(0x063A,ayn,{"init":[dot(264,491)],"medi":[dot(228,414)],
                     "isol":[dot(305,492)],"fina":[dot(305,492)]})

    # Fa/qaf: a circular head, a narrow neck, and a distinctly lower qaf bowl.
    fa_head = path((250,208),Q((184,216),(186,282)),Q((191,345),(251,347)),
                   Q((319,351),(342,291)),Q((358,221),(295,206)),L((250,208)))
    fa = {
        "init":glyph(415,[fa_head,path((303,210),Q((303,116),(237,82)),L((0,70)))],anchor_x=263),
        "medi":glyph(445,[fa_head,path((445,70),L((344,70)),Q((322,99),(326,214))),
                          path((250,208),Q((246,119),(195,82)),L((0,70)))],anchor_x=263),
        "isol":glyph(630,[translated(fa_head,200),path((506,214),Q((525,82),(452,30)),
                       C((364,-8),(202,-21),(122,7)),Q((59,42),(79,207)))],anchor_x=440),
        "fina":glyph(675,[translated(fa_head,200),path((675,70),L((531,70))),
                       path((506,214),Q((525,82),(452,30)),
                       C((364,-8),(202,-21),(122,7)),Q((59,42),(79,207)))],anchor_x=440)
    }
    family(0x0641,fa,{"init":[dot(266,461)],"medi":[dot(266,461)],
                     "isol":[dot(466,461)],"fina":[dot(466,461)]})
    family(0x06A4,fa,{f:[dot(x-42,456),dot(x+42,456),dot(x,535)]
                         for f,x in (("init",266),("medi",266),("isol",466),("fina",466))})
    qaf = deepcopy(fa)
    qaf["isol"] = glyph(625,[translated(fa_head,155),path((461,218),Q((489,65),(447,-41)),
                       C((391,-189),(204,-216),(119,-124)),Q((64,-65),(93,184)))],anchor_x=394)
    qaf["fina"] = glyph(680,[translated(fa_head,155),path((680,70),L((481,70))),
                       path((461,218),Q((489,65),(447,-41)),
                       C((391,-189),(204,-216),(119,-124)),Q((64,-65),(93,184)))],anchor_x=394)
    family(0x0642,qaf,{"init":[dot(224,461),dot(308,461)],
                       "medi":[dot(224,461),dot(308,461)],
                       "isol":[dot(379,461),dot(463,461)],
                       "fina":[dot(379,461),dot(463,461)]})

    # Kaf's isolated counter has a small hand-drawn internal kaf stroke.
    kaf_base = path((459,649),Q((450,386),(468,147)),Q((467,51),(382,27)),
                    C((289,0),(151,5),(99,47)),Q((70,82),(85,204)))
    kaf_small = path((276,364),Q((229,391),(197,345)),Q((182,321),(218,306)),
                     L((278,296)),Q((259,267),(200,244)))
    kaf_join = path((362,649),Q((266,536),(139,429)),Q((221,361),(298,280)),
                    Q((312,141),(234,90)),Q((177,70),(0,70)))
    kaf = {
        "isol":glyph(555,[kaf_base,kaf_small],anchor_x=343),
        "init":glyph(430,[kaf_join],anchor_x=287),
        "medi":glyph(480,[kaf_join,path((480,70),L((270,70)),Q((253,75),(244,88)))],anchor_x=287),
        "fina":glyph(650,[kaf_base,kaf_small,path((650,70),L((451,70)))],anchor_x=343)
    }
    add(0x0643,kaf)
    persian_kaf=deepcopy(kaf)
    for form in ("isol","fina"):
        persian_kaf[form]["strokes"].remove(persian_kaf[form]["strokes"][1])
        persian_kaf[form]["strokes"].append(path((458,604),Q((346,511),(240,440))))
    add(0x06A9,persian_kaf)
    gaf=deepcopy(persian_kaf)
    for form,g in gaf.items():
        if form in ("isol","fina"):
            g["strokes"].append(path((449,748),Q((336,655),(248,597))))
        else:
            g["strokes"].append(path((310,748),Q((221,657),(143,593))))
        g["anchors"]["top"]=(g["anchors"]["top"][0],854)
    add(0x06AF,gaf)

    # Lam has the same flowing tall stem as alif, with a lower bowl in finals.
    lam = {
        "isol":glyph(450,[path((357,661),Q((345,384),(361,145)),
                      Q((363,-16),(295,-117)),C((223,-210),(114,-190),(83,-102)),
                      Q((59,-29),(91,173)))],anchor_x=285),
        "init":glyph(260,[path((177,661),Q((161,382),(179,161)),
                      Q((181,90),(131,75)),L((0,70)))],anchor_x=177),
        "medi":glyph(320,[path((177,661),Q((162,381),(180,156)),
                      Q((183,91),(135,75)),L((0,70))),path((320,70),L((159,70)))],anchor_x=177),
        "fina":glyph(545,[path((545,70),L((352,70))),
                      path((357,661),Q((345,384),(361,145)),
                      Q((363,-16),(295,-117)),C((223,-210),(114,-190),(83,-102)),
                      Q((59,-29),(91,173)))],anchor_x=285)
    }
    add(0x0644,lam)

    # Mim keeps its loop above the join and an unmistakable descending tail.
    mim_loop = path((188,79),Q((270,78),(292,152)),Q((312,221),(246,262)),
                    Q((172,271),(140,205)),Q((113,132),(188,79)))
    mim = {
        "init":glyph(365,[mim_loop,path((188,79),Q((111,70),(0,70)))],anchor_x=218),
        "medi":glyph(405,[mim_loop,path((405,70),L((296,70)),Q((277,82),(265,106))),
                          path((188,79),Q((111,70),(0,70)))],anchor_x=218),
        "isol":glyph(440,[translated(mim_loop,83,75),
                      path((274,154),Q((171,83),(146,-12)),Q((128,-128),(145,-221)))],anchor_x=286),
        "fina":glyph(500,[translated(mim_loop,83,75),
                      path((500,70),L((385,70)),Q((346,99),(355,196))),
                      path((274,154),Q((171,83),(146,-12)),Q((128,-128),(145,-221)))],anchor_x=286)
    }
    add(0x0645,mim)

    noon=deepcopy(ba)
    noon["isol"]=glyph(555,[path((463,244),Q((490,71),(427,-59)),
                       C((370,-178),(182,-200),(104,-106)),Q((60,-46),(81,220)))],anchor_x=275)
    noon["fina"]=glyph(620,[path((620,70),L((478,70)),Q((459,-58),(409,-103)),
                       C((326,-196),(171,-192),(99,-101)),Q((59,-45),(79,221)))],anchor_x=275)
    family(0x0646,noon,{"isol":[dot(272,215)],"init":[dot(168,363)],
                       "medi":[dot(170,363)],"fina":[dot(271,220)]})

    # Heh has a single closed terminal eye and two different joining eyes.
    heh_eye=path((296,95),Q((339,186),(289,269)),Q((238,335),(156,289)),
                  Q((91,250),(105,137)),Q((114,39),(215,48)),Q((271,50),(296,95)))
    heh = {
        "isol":glyph(400,[heh_eye],anchor_x=217),
        "init":glyph(395,[path((285,344),Q((336,284),(311,193)),
                      Q((292,131),(208,111)),Q((144,104),(130,177)),
                      Q((133,251),(217,266)),Q((296,281),(314,208)),
                      Q((326,122),(270,83)),Q((214,70),(0,70))),
                      path((160,122),Q((179,72),(221,72)))],anchor_x=226),
        "medi":glyph(405,[path((405,70),L((218,70))),
                      path((208,73),Q((280,126),(273,210)),Q((263,280),(196,274)),
                      Q((126,251),(121,168)),Q((126,99),(208,73))),
                      path((208,73),Q((262,4),(227,-60)),Q((190,-110),(130,-63)),
                      Q((100,-19),(138,39)),Q((163,65),(208,73))),
                      path((151,70),L((0,70)))],anchor_x=208),
        "fina":glyph(470,[heh_eye,path((470,70),L((317,70)),Q((302,84),(306,123)))],anchor_x=217)
    }
    add(0x0647,heh)
    family(0x0629,{f:heh[f] for f in ("isol","fina")},
            {"isol":[dot(177,416),dot(261,416)],"fina":[dot(177,416),dot(261,416)]},"right")
    add(0x06C1,heh)

    # Waw's eye sits above the baseline, with a sloping long open tail.
    waw_eye=path((199,187),Q((296,166),(326,243)),Q((341,314),(273,336)),
                  Q((212,357),(182,288)),Q((161,224),(199,187)))
    waw = {
        "isol":glyph(390,[waw_eye,path((315,208),Q((304,49),(225,-74)),
                      Q((149,-178),(65,-170)),L((42,-146)))],anchor_x=249),
        "fina":glyph(470,[waw_eye,path((470,70),L((299,70))),
                      path((315,208),Q((304,49),(225,-74)),
                      Q((149,-178),(65,-170)),L((42,-146)))],anchor_x=249)
    }
    add(0x0648,waw,"right")
    waw_hamza=deepcopy(waw)
    for g in waw_hamza.values():
        g["strokes"].append(hamza_at(236,480));g["anchors"]["top"]=(249,660)
    add(0x0624,waw_hamza,"right")

    # Yeh has a gently hooked left lip, a deep bowl, and well-spaced dots.
    yeh=deepcopy(ba)
    yeh["isol"]=glyph(650,[path((545,293),Q((572,193),(509,129)),
                    Q((452,81),(367,113)),Q((300,144),(248,198)),
                    Q((175,228),(125,173)),Q((60,110),(78,-5)),
                    C((97,-177),(312,-219),(452,-119)),Q((491,-84),(442,-49)),
                    Q((405,-20),(349,-28)))],anchor_x=300)
    yeh["fina"]=glyph(680,[path((680,70),L((533,70)),Q((516,-23),(445,-92)),
                    C((344,-190),(189,-188),(108,-102)),Q((55,-49),(77,48)),
                    Q((104,151),(202,133)),Q((269,125),(315,62)))],anchor_x=306)
    family(0x064A,yeh,{"isol":[dot(241,-280),dot(325,-280)],
                       "init":[dot(112,-46),dot(196,-46)],
                       "medi":[dot(114,-46),dot(198,-46)],
                       "fina":[dot(241,-279),dot(325,-279)]})
    add(0x0649,yeh)
    persian_yeh=deepcopy(yeh)
    # Persian yeh is dotless in isolated/final shapes, dotted in joined shapes.
    family(0x06CC,persian_yeh,{"init":[dot(112,-46),dot(196,-46)],
                              "medi":[dot(114,-46),dot(198,-46)]})
    yeh_hamza=deepcopy(yeh)
    for form,g in yeh_hamza.items():
        x=170 if form in ("init","medi") else 385
        h=370 if form in ("init","medi") else 429
        g["strokes"].append(hamza_at(x,h));g["anchors"]["top"]=(x,h+180)
    add(0x0626,yeh_hamza)

    tatweel=glyph(300,[path((0,70),Q((103,77),(158,70)),Q((227,63),(300,70)))],anchor_x=150,top=240,bottom=-80)
    add(0x0640,{form:tatweel for form in ("isol","init","medi","fina")})

    return result, unicode_map, joins


_GLYPHS, _CMAP, _JOINING = _build()


def get_glyphs():
    return deepcopy(_GLYPHS)


def cmap():
    return dict(_CMAP)


def joining():
    return dict(_JOINING)


def validate():
    """Structural checks independent of the outline/font builder."""
    errors=[]
    for cp,j in _JOINING.items():
        n=_CMAP[cp]
        for form in (("isol","init","medi","fina") if j=="dual" else
                     ("isol","fina") if j=="right" else ("isol",)):
            key=n if form=="isol" else n+"."+form
            if key not in _GLYPHS:
                errors.append((key,"missing"));continue
            g=_GLYPHS[key]
            endpoints=[s[0] for s in g["strokes"]]+[s[-1] for s in g["strokes"]]
            if form in ("init","medi") and (0,70) not in endpoints:
                errors.append((key,"missing left join"))
            if form in ("medi","fina") and (g["width"],70) not in endpoints:
                errors.append((key,"missing right join"))
            if not g["strokes"] or any(len(s)<2 for s in g["strokes"]):
                errors.append((key,"invalid stroke"))
    return errors


if __name__ == "__main__":
    errors=validate()
    print(f"{len(_CMAP)} Unicode letters; {len(_GLYPHS)} contextual glyphs")
    print("join validation:",errors or "PASS")
    if errors: raise SystemExit(1)
